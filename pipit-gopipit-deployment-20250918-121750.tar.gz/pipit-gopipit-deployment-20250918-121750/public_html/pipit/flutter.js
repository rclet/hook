// Flutter.js placeholder for gopipit.com deployment
window._flutter = window._flutter || {};
window._flutter.loader = {
  loadEntrypoint: function(config) {
    console.log('Loading Pipit Flutter app for gopipit.com');
    return new Promise(function(resolve) {
      setTimeout(function() {
        resolve({
          initializeEngine: function() {
            return Promise.resolve({
              runApp: function() {
                console.log('Pipit app running on gopipit.com');
                return Promise.resolve();
              }
            });
          }
        });
      }, 500);
    });
  }
};