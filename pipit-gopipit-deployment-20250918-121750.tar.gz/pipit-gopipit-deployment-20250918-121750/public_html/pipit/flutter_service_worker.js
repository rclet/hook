// Flutter service worker placeholder
console.log('Pipit service worker loaded for gopipit.com');

// Basic service worker for PWA functionality
self.addEventListener('install', function(event) {
  console.log('Service worker installing for Pipit app');
});

self.addEventListener('activate', function(event) {
  console.log('Service worker activating for Pipit app');
});

self.addEventListener('fetch', function(event) {
  // Handle fetch events for offline support
  console.log('Handling fetch event for:', event.request.url);
});